package com.zhangyihao.cloudmusic;

import android.os.Bundle;

import com.zhangyihao.cloudmusic.activity.BaseActivity;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
