package com.zhangyihao.cloudmusic;

import android.app.Application;

/**
 * Created by zhangyihao on 16/1/18.
 */
public class MyApp extends Application {

}
