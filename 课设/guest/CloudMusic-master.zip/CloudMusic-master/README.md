# CloudMusic
网易云音乐播放器--Qt

Qt实现的一个音乐播放器。
爬取了网易云上面播放数超过50w的歌单。


![image](https://github.com/Nyloner/CloudMusic/blob/master/screenshot/2015-11-29%2013:13:59%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png)
