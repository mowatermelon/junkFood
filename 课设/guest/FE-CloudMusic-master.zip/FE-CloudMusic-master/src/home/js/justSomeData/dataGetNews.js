define([
    {
        title: '迎新年，全民福利活动Let’s Go！',
        pubDate: '2016-01-08'
    },
    {
        title: '银翼邮递员传递祝福！圣诞祝福征集正式开始',
        pubDate: '2016-01-07'
    },
    {
        title: '12·12线上活动，买赠大行动！',
        pubDate: '2015-11-19'
    },
    {
        title: '新专辑体验资格已更新，请登录页面查询',
        pubDate: '2016-01-07'
    },
    {
        title: '猜歌无级限 活动嗨不停',
        pubDate: '2016-01-10'
    },
    {
        title: '节日歌单大折扣',
        pubDate: '2016-01-16'
    },
    {
        title: '音乐概念站·Silver Light From The Above',
        pubDate: '2016-01-22'
    }
]);