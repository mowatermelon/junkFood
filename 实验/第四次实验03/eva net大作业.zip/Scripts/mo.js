
function showIndex() {
    document.getElementById("Tran").style.display = "none";
    document.getElementById("Index").style.display = "block";
    document.getElementById("Kind").style.display = "none";
    document.getElementById("Prod").style.display = "none";
    document.getElementById("Cont").style.display = "none";
    document.getElementById("span_Tran").style.backgroundColor = "#F4A460";
    document.getElementById("span_Index").style.backgroundColor = "#fff";
    document.getElementById("span_Kind").style.backgroundColor = "#F4A460";
    document.getElementById("TOP_IMG").style.opacity = "1";
    document.getElementById("span_Prod").style.backgroundColor = "#F4A460";
    document.getElementById("span_Cont").style.backgroundColor = "#F4A460";
    document.getElementById("span_Index").style.color = "#000";
	}

function showTran() {
    document.getElementById("Tran").style.display = "block";
    document.getElementById("Index").style.display = "none";
    document.getElementById("Kind").style.display = "none";
    document.getElementById("Prod").style.display = "none";
    document.getElementById("Cont").style.display = "none";
    document.getElementById("span_Tran").style.backgroundColor = "#fff";
    document.getElementById("span_Index").style.backgroundColor = "#F4A460";
    document.getElementById("span_Kind").style.backgroundColor = "#F4A460";
    document.getElementById("TOP_IMG").style.opacity = "1";
    document.getElementById("span_Prod").style.backgroundColor = "#F4A460";
    document.getElementById("span_Cont").style.backgroundColor = "#F4A460";
    document.getElementById("span_Tran").style.color = "#000";
	}

function showKind() {
    document.getElementById("Tran").style.display = "none";
    document.getElementById("Index").style.display = "none";
    document.getElementById("Kind").style.display = "block";
    document.getElementById("Prod").style.display = "none";
    document.getElementById("Cont").style.display = "none";
    document.getElementById("span_Tran").style.backgroundColor = "#F4A460";
    document.getElementById("span_Index").style.backgroundColor = "#F4A460";
    document.getElementById("span_Kind").style.backgroundColor = "#fff";
    document.getElementById("TOP_IMG").style.opacity = "0.5";
    document.getElementById("span_Prod").style.backgroundColor = "#F4A460";
    document.getElementById("span_Cont").style.backgroundColor = "#F4A460";
    document.getElementById("span_Kind").style.color = "#000";
	}

function showProd() {
    document.getElementById("Tran").style.display = "none";
    document.getElementById("Index").style.display = "none";
    document.getElementById("Kind").style.display = "none";
    document.getElementById("Prod").style.display = "block";
    document.getElementById("Cont").style.display = "none";
    document.getElementById("span_Tran").style.backgroundColor = "#F4A460";
    document.getElementById("span_Index").style.backgroundColor = "#F4A460";
    document.getElementById("span_Kind").style.backgroundColor = "#F4A460";
    document.getElementById("TOP_IMG").style.opacity = "1";
    document.getElementById("span_Prod").style.backgroundColor = "#fff";
    document.getElementById("span_Cont").style.backgroundColor = "#F4A460";
    document.getElementById("span_Prod").style.color = "#000";
	}

function showCont() {
    document.getElementById("Tran").style.display = "none";
    document.getElementById("Index").style.display = "none";
    document.getElementById("Kind").style.display = "none";
    document.getElementById("Prod").style.display = "none";
    document.getElementById("Cont").style.display = "block";
    document.getElementById("span_Tran").style.backgroundColor = "#F4A460";
    document.getElementById("span_Index").style.backgroundColor = "#F4A460";
    document.getElementById("span_Kind").style.backgroundColor = "#F4A460";
    document.getElementById("TOP_IMG").style.opacity = "1";
    document.getElementById("span_Prod").style.backgroundColor = "#F4A460";
    document.getElementById("span_Cont").style.backgroundColor = "#fff";
    document.getElementById("span_Cont").style.color = "#000";
	}


