package com.fireawayh.cloudmusic.utils;

/**
 * By FireAwayH on 15/11/10.
 */
public class Logger {
    public Logger(){

    }
    public void print(String str){
        System.out.println(str);
    }
}
